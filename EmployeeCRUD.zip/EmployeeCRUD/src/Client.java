import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sleeping");
		EntityManager entityManager = factory.createEntityManager();

		// persist()-->insert,merge-->update,-->remove-->Delete,find()-->fetch
		entityManager.getTransaction().begin();
//		Employee emp = new Employee(124, "rajesh",42000, "trainer");
//
//		entityManager.persist(emp);// ORM
		
		
		Employee emp=	entityManager.find(Employee.class, 124);
		System.out.println(emp);
		
//		emp.setEmpName("supriya");
//		emp.setEmpDesg("CEO");
//		emp.setEmpSal(100000);
//		entityManager.merge(emp);
		
		entityManager.remove(emp);
		
		entityManager.getTransaction().commit();
//student crud
	}
}
