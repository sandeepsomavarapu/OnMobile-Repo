package com.onmobile.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Client {
	public static void main(String[] args) {
		HashMap<Long, Employee> emps = new HashMap<Long, Employee>();
		int empId, empSal = 0;
		String empName, empDesg = null;
		long contact = 0;
		while (true) {
			Scanner scan = new Scanner(System.in);
			System.out.println("***************Employee Management Application*******");
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.Get Employee");
			System.out.println("5.GetAll Employees");
			System.out.println("6.Exit");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Add Employee:");
				System.out.println("Enter employee id ");
				empId = scan.nextInt();
				System.out.println("Enter employee name ");
				empName = scan.next();
				System.out.println("Enter employee salary ");
				empSal = scan.nextInt();
				System.out.println("Enter employee desg ");
				empDesg = scan.next();
				System.out.println("Enter your contact ");
				contact = scan.nextLong();

				Employee emp = new Employee(empId, empName, empSal, empDesg);
				emps.put(contact, emp);
				System.out.println("Employee inserted Successfully");
				break;
			case 2:

				System.out.println("Update Employee:");
				System.out.println("Enter your contact ");
				contact = scan.nextLong();
				System.out.println("Enter employee id ");
				empId = scan.nextInt();
				System.out.println("Enter employee name ");
				empName = scan.next();
				System.out.println("Enter employee salary ");
				empSal = scan.nextInt();
				System.out.println("Enter employee desg ");
				empDesg = scan.next();

				Employee emp1 = new Employee(empId, empName, empSal, empDesg);
				emps.put(contact, emp1);
				System.out.println("Employee Updated Successfully");
				break;
			case 3:
				System.out.println("Remove Employee:");
				System.out.println("Enter your contact ");
				contact = scan.nextLong();
				emps.remove(contact);
				System.out.println("Employee Removed Successfully");
				break;
			case 4:
				System.out.println("Get Employee:");
				System.out.println("Enter your contact ");
				contact = scan.nextLong();
				System.out.println(emps.get(contact));
				break;
			case 5:
				Set<Long> set = emps.keySet();
				Iterator<Long> keys = set.iterator();
				while (keys.hasNext()) {

					System.out.println(emps.get(keys.next()));
				}
				break;
			default:
				System.out.println("Thank you ********");
				System.exit(0);
				break;
			}
		}
	}
}
