package com.java8features;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateAndTimeAPiEx {
	public static void main(String[] args) {
//		Date date1 = new Date();
//		System.out.println(date1);
//
//		LocalDate date = LocalDate.now();// immuttable
//		System.out.println(date);
//
//		LocalTime time = LocalTime.now();
//		System.out.println(time);
//		LocalDateTime dateTime = LocalDateTime.now();
//		System.out.println(dateTime);

		LocalDate date = LocalDate.now();// systemdate
		LocalDate bDate = LocalDate.of(1993, 11, 10);
		Period p = Period.between(bDate, date);
		System.out.printf("ur age %d years,%d months,%d days", p.getYears(), p.getMonths(), p.getDays());
		System.out.println();
		ZoneId zone = ZoneId.of("America/New_York");
		ZonedDateTime zt = ZonedDateTime.now(zone);
		System.out.println(zt);
	}
}
