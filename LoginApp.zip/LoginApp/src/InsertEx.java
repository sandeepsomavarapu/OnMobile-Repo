import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

public class InsertEx {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/onmobile?useSSL=false", "root",
				"rpsconsulting");
		Random random = new Random();
		int userid =0;
		Scanner scan = new Scanner(System.in);

		while (true) {
			System.out.println("Gmail Aplication");
			System.out.println("1.Register here ");
			System.out.println("2.Login  here");
			System.out.println("3.Exit");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				userid= random.nextInt((9999 - 100) + 1) + 10;
					System.out.println(userid);
				System.out.println("Enter FirstName");
				String fname = scan.next();
				System.out.println("Enter UserName");
				String uname = scan.next();
				System.out.println("Enter Password");
				String password = scan.next();
				
				PreparedStatement stmt = conn.prepareStatement("insert into gmail values(?,?,?,?)");// postional params
				stmt.setInt(1, userid);
				stmt.setString(2, fname);
				stmt.setString(3, uname);
				stmt.setString(4, password);
				int result = stmt.executeUpdate();
				if (result > 0) {
					System.out.println("Registered Successfully..");
				}
				break;
			case 2:
				System.out.println("Enter UserName");
				String username = scan.next();
				System.out.println("Enter Password");
				String pwd = scan.next();
				PreparedStatement stmt1 = conn.prepareStatement("select * from gmail where username=? and password=?");// postional
																														// params
				stmt1.setString(1, username);
				stmt1.setString(2, pwd);
				ResultSet result1 = stmt1.executeQuery();
				if (result1.next()) {
					System.out.println("Login Successfull Mr:" + result1.getString(2));
				}

				break;
			default:
				System.out.println("Thank You");

				scan.close();
				conn.close();
				System.exit(0);
				break;
			}
		}
	}

}
