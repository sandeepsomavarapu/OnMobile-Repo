package com.onmobile;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		PrintWriter out = response.getWriter();
		Class.forName("com.mysql.cj.jdbc.Driver");

		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/onmobile", "root", "rpsconsulting");

		Random random = new Random();
		int userid = random.nextInt((9999 - 100) + 1) + 10;
		System.out.println(userid);
		String name = request.getParameter("name");
		String username = request.getParameter("uname");
		String password = request.getParameter("pass");

		PreparedStatement stmt = conn.prepareStatement("insert into gmail values(?,?,?,?)");// postional params
		stmt.setInt(1, userid);
		stmt.setString(2, name);
		stmt.setString(3, username);
		stmt.setString(4, password);
		int result = stmt.executeUpdate();
		if (result > 0) {
			out.println("Registered Successfully..");
		}
		}catch (Exception e) {
			System.out.println(e);
		}

	}

}
